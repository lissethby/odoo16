# -*- coding: utf-8 -*-
from . import autor
from . import genero
from . import autor_libro
from . import libro
from . import prestamo
from . import res_partner